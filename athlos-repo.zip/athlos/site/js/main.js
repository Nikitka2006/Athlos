// Athlos — общая логика сайта: шапка/подвал, корзина (localStorage), каталог, товар, оформление заказа.
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const money=n=>n.toLocaleString('ru-RU')+' ₽';
const pl=n=>n%10==1&&n%100!=11?'товар':[2,3,4].includes(n%10)&&![12,13,14].includes(n%100)?'товара':'товаров';
const find=id=>PRODUCTS.find(p=>p.id===id);
const tub=h=>`<div class="tub" style="--h:${h}px"><span>ATHLOS</span></div>`;

/* ---- корзина ---- */
const getCart=()=>JSON.parse(localStorage.getItem('athlos_cart')||'[]');
const setCart=c=>{localStorage.setItem('athlos_cart',JSON.stringify(c));updateCount();};
const updateCount=()=>{const n=getCart().reduce((a,i)=>a+i.q,0);$$('.cart-count').forEach(e=>e.textContent=n);};
function toast(t){let e=$('#toast');if(!e){e=document.createElement('div');e.id='toast';e.setAttribute('role','status');document.body.append(e);}e.textContent=t;e.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove('show'),2000);}
function addToCart(id,f,s,q=1){const c=getCart(),it=c.find(i=>i.id===id&&i.f===f&&i.s===s);it?it.q=Math.min(20,it.q+q):c.push({id,f,s,q});setCart(c);toast('Добавлено в корзину');}
document.addEventListener('click',e=>{const b=e.target.closest('[data-add]');if(b){const p=find(+b.dataset.add);addToCart(p.id,p.f[0],0);}});

/* ---- пользователи (демо: данные в браузере; в реальном проекте регистрация и пароли обрабатываются на сервере) ---- */
const jget=(k,d)=>JSON.parse(localStorage.getItem(k)||d),jset=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
const users=()=>jget('athlos_users','[]');
const U=users().find(u=>u.email===localStorage.getItem('athlos_user'));
const hash=async s=>{try{return[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode('athlos:'+s)))].map(b=>b.toString(16).padStart(2,'0')).join('');}catch(e){return btoa(unescape(encodeURIComponent(s)));}};
const next=()=>{const n=new URLSearchParams(location.search).get('next')||'';return /^[\w-]+\.html$/.test(n)?n:'account.html';};
const acc=U?`<a class="login-link" href="account.html">${U.name.split(' ')[0]}</a>`:'<a class="login-link" href="login.html">Войти</a>';

/* ---- шапка и подвал ---- */
const cur=document.body.dataset.cat||new URLSearchParams(location.search).get('cat');
document.body.insertAdjacentHTML('afterbegin',`<header class="site"><div class="wrap bar"><a class="logo" href="index.html"><i>A</i>ATHLOS</a><nav><a href="catalog.html" class="${document.body.dataset.page==='catalog'&&!cur?'on':''}">Каталог</a>${Object.entries(CATS).map(([k,v])=>`<a href="${k}.html" class="${cur===k?'on':''}">${v}</a>`).join('')}<a href="sale.html" class="${cur==='sale'?'on':''}">Акции</a></nav><form class="search" action="catalog.html"><input name="q" placeholder="Поиск товаров" aria-label="Поиск товаров"></form>${acc}<a class="cart-link" href="cart.html">Корзина · <span class="cart-count">0</span></a></div></header>`);
document.body.insertAdjacentHTML('beforeend',`<footer class="site-f"><div class="wrap foot"><div><a class="logo" href="index.html"><i>A</i>ATHLOS</a><p>Спортивное питание с греческим характером</p></div><div><h4>Каталог</h4>${Object.entries(CATS).map(([k,v])=>`<a href="${k}.html">${v}</a>`).join('')}</div><div><h4>Покупателям</h4><a href="cart.html">Корзина</a><a href="info.html#delivery">Доставка и оплата</a><a href="info.html#returns">Возврат</a><a href="points.html">Пункты выдачи и залы</a><a href="${U?'account.html':'login.html'}">Личный кабинет</a></div><div><h4>Контакты</h4><a href="tel:+78000000000">+7 (800) 000-00-00</a><a href="mailto:hello@athlos.shop">hello@athlos.shop</a><p>Ежедневно, 9:00–21:00</p></div></div><div class="wrap copy">© 2026 Athlos. Учебный проект интернет-магазина спортивного питания.</div></footer>`);
updateCount();

/* ---- карточка товара ---- */
const card=p=>`<article class="card"><a class="card-img" href="product.html?id=${p.id}">${p.t?`<span class="badge">${p.t}</span>`:''}${tub(170)}</a><div class="card-body"><small>${CATS[p.c]}</small><h3><a href="product.html?id=${p.id}">${p.n} ${p.s[0][0]}</a></h3><div class="rate">★ ${p.r} · ${p.rv} отзывов</div><div class="buy"><span><b>${money(p.s[0][1])}</b>${p.d?` <s>${money(Math.round(p.s[0][1]/(1-p.d/100)/10)*10)}</s>`:''}</span><button class="btn sm" data-add="${p.id}">В корзину</button></div></div></article>`;

const getPoint=()=>POINTS.find(x=>x.id===+localStorage.getItem('athlos_point'));
/* ---- главная ---- */
if($('#hits')){
 $('#hits').innerHTML=[1,5,7,10].map(i=>card(find(i))).join('');
 $('#cats').innerHTML=Object.entries(CATS).map(([k,v])=>{const n=PRODUCTS.filter(p=>p.c===k).length;return`<a class="cat" href="${k}.html"><b>${v}</b><small>${n} ${pl(n)}</small></a>`;}).join('');
}

/* ---- каталог ---- */
if($('#grid')){
 const qs=new URLSearchParams(location.search),q=(qs.get('q')||'').toLowerCase().trim(),f=$('#filters');
 $('#f-cat').innerHTML=[['','Все'],...Object.entries(CATS)].map(([k,v])=>`<label><input type="radio" name="cat" value="${k}"${k===(qs.get('cat')||'')?' checked':''}>${v}</label>`).join('');
 $('#f-brand').innerHTML=[...new Set(PRODUCTS.map(p=>p.b))].map(b=>`<label><input type="checkbox" name="brand" value="${b}">${b}</label>`).join('');
 const draw=()=>{
  const cat=f.cat.value,br=$$('[name=brand]:checked',f).map(i=>i.value),min=+f.min.value||0,max=+f.max.value||Infinity,sort=$('#sort').value;
  const list=PRODUCTS.filter(p=>(!cat||p.c===cat)&&(!br.length||br.includes(p.b))&&p.s[0][1]>=min&&p.s[0][1]<=max&&(!q||(p.n+' '+p.b+' '+CATS[p.c]).toLowerCase().includes(q)))
   .sort((a,b)=>sort==='asc'?a.s[0][1]-b.s[0][1]:sort==='desc'?b.s[0][1]-a.s[0][1]:sort==='rate'?b.r-a.r:b.rv-a.rv);
  const t=cat?CATS[cat]:q?'Поиск: '+qs.get('q'):'Каталог';
  $('#title').textContent=t;$('#crumb').textContent=cat||q?' / '+t:'';document.title=t+' — Athlos';
  $('#count').textContent=list.length+' '+pl(list.length);
  $('#grid').innerHTML=list.map(card).join('')||'<p class="empty">Ничего не найдено. Измените фильтры или <a href="catalog.html">сбросьте поиск</a>.</p>';
 };
 f.addEventListener('input',draw);$('#sort').addEventListener('change',draw);f.addEventListener('reset',()=>setTimeout(draw));draw();
}

/* ---- страница товара ---- */
if($('#product')){
 const p=find(+new URLSearchParams(location.search).get('id')),box=$('#product');
 if(!p){box.innerHTML='<p class="empty">Товар не найден. <a href="catalog.html">Вернуться в каталог</a></p>';$('.tabs').hidden=true;$('.sec').hidden=true;}
 else{
  document.title=p.n+' — Athlos';$('#crumb').textContent=p.n;$('#crumb-cat').textContent=CATS[p.c];$('#crumb-cat').href=p.c+'.html';
  let f=p.f[0],s=0,q=1;
  box.innerHTML=`<div class="gallery">${tub(380)}</div><div class="info"><small>${CATS[p.c]}</small><h1>${p.n}</h1><div class="rate">★ ${p.r} · ${p.rv} отзывов · В наличии</div>
  <div class="price"><b id="price"></b>${p.d?`<s id="old"></s><span class="badge">−${p.d}%</span>`:''}</div>
  <div class="opt"><h4>Вкус</h4><div class="chips">${p.f.map((x,i)=>`<button class="chip${i?'':' on'}" data-k="f" data-v="${x}">${x}</button>`).join('')}</div></div>
  <div class="opt"><h4>Объём</h4><div class="chips">${p.s.map((x,i)=>`<button class="chip${i?'':' on'}" data-k="s" data-v="${i}">${x[0]}</button>`).join('')}</div></div>
  <div class="buy-row"><div class="qty"><button aria-label="Меньше" data-q="-1">−</button><span id="q">1</span><button aria-label="Больше" data-q="1">+</button></div><button class="btn" id="add">Добавить в корзину</button><button class="btn ghost" id="one">Купить в 1 клик</button></div>
  <dl class="facts"><div><dt>Бренд</dt><dd>${p.b}</dd></div><div><dt>Категория</dt><dd>${CATS[p.c]}</dd></div><div><dt>Доставка</dt><dd>Завтра, бесплатно от 3 000 ₽</dd></div></dl></div>`;
  const price=()=>{const v=p.s[s][1];$('#price').textContent=money(v);if(p.d)$('#old').textContent=money(Math.round(v/(1-p.d/100)/10)*10);};price();
  box.addEventListener('click',e=>{
   const c=e.target.closest('.chip');if(c){$$('.chip',c.parentElement).forEach(x=>x.classList.toggle('on',x===c));if(c.dataset.k==='f')f=c.dataset.v;else{s=+c.dataset.v;price();}}
   const b=e.target.closest('[data-q]');if(b){q=Math.max(1,Math.min(20,q+ +b.dataset.q));$('#q').textContent=q;}});
  $('#add').onclick=()=>addToCart(p.id,f,s,q);
  $('#one').onclick=()=>{addToCart(p.id,f,s,q);location.href='cart.html';};
  const I=INFO[p.c],tabs=[['Описание',I[0]],['Состав',I[1]],['Применение',I[2]],['Отзывы ('+p.rv+')','Средняя оценка '+p.r+' из 5 на основе '+p.rv+' отзывов покупателей.']];
  const showTab=n=>{$$('button',$('#tabbar')).forEach((b,i)=>b.classList.toggle('on',i===n));$('#panel').textContent=tabs[n][1];};
  $('#tabbar').innerHTML=tabs.map((t,i)=>`<button role="tab" data-t="${i}">${t[0]}</button>`).join('');
  $('#tabbar').onclick=e=>{const b=e.target.closest('[data-t]');if(b)showTab(+b.dataset.t);};showTab(0);
  $('#related').innerHTML=PRODUCTS.filter(x=>x.id!==p.id).sort((a,b)=>(b.c===p.c)-(a.c===p.c)).slice(0,4).map(card).join('');
 }
}

/* ---- корзина и оформление заказа ---- */
if($('#items')){
 let promo=false;const f=$('#order'),E=f.elements;
 if(U){E.fullname.value=U.name;E.phone.value=U.phone;E.email.value=U.email;$('#guest').hidden=true;}
 const FL=['fullname','phone','email','address','pay'],dr=jget('athlos_draft','{}');FL.forEach(n=>{if(dr[n])E[n].value=dr[n];});
 f.addEventListener('input',()=>jset('athlos_draft',Object.fromEntries(FL.map(n=>[n,E[n].value]))));
 const calc=()=>{const c=getCart(),sub=c.reduce((a,i)=>a+find(i.id).s[i.s][1]*i.q,0),ship=E.delivery.value==='courier'&&sub&&sub<3000?300:0,disc=promo?Math.round(sub*.1):0;return{c,sub,ship,disc,total:sub+ship-disc};};
 const draw=()=>{
  const{c,sub,ship,disc,total}=calc();
  $('#empty').hidden=c.length>0;$('#cart-wrap').hidden=!c.length;
  $('#items').innerHTML=c.map((i,n)=>{const p=find(i.id);return`<article class="item"><a class="thumb" href="product.html?id=${p.id}">${tub(70)}</a><div><h3><a href="product.html?id=${p.id}">${p.n} ${p.s[i.s][0]}</a></h3><small>Вкус: ${i.f}</small><br><button class="rm" data-del="${n}">Удалить</button></div><div class="qty"><button aria-label="Меньше" data-i="${n}" data-d="-1">−</button><span>${i.q}</span><button aria-label="Больше" data-i="${n}" data-d="1">+</button></div><div class="sum">${money(p.s[i.s][1]*i.q)}</div></article>`;}).join('');
  $('#sub').textContent=money(sub);$('#ship').textContent=ship?money(ship):'Бесплатно';$('#disc').textContent=disc?'−'+money(disc):'0 ₽';$('#total').textContent=money(total);
 };
 $('#items').addEventListener('click',e=>{
  const c=getCart(),d=e.target.closest('[data-d]'),r=e.target.closest('[data-del]');
  if(d){const it=c[+d.dataset.i];it.q=Math.max(1,Math.min(20,it.q+ +d.dataset.d));}else if(r)c.splice(+r.dataset.del,1);else return;
  setCart(c);draw();});
 $('#apply').onclick=()=>{promo=$('#promo').value.trim().toUpperCase()==='ATHLOS10';$('#promo-msg').textContent=promo?'Промокод применён: скидка 10%':'Такого промокода нет';draw();};
 E.delivery.onchange=()=>{const pt=E.delivery.value==='point',p=getPoint();localStorage.setItem('athlos_delivery',E.delivery.value);E.address.required=!pt;$('#addr').hidden=pt;$('#point-box').hidden=!pt;
  $('#point-name').textContent=p?p.n:'Пункт не выбран';$('#point-addr').textContent=p?p.city+', '+p.a+'. '+p.h:'';$('#point-link').textContent=p?'Выбрать другой пункт':'Выбрать пункт выдачи или зал';draw();};
 if(localStorage.getItem('athlos_delivery')==='point'&&getPoint())E.delivery.value='point';E.delivery.onchange();
 f.onsubmit=e=>{
  e.preventDefault();if(!f.reportValidity())return;
  if(E.delivery.value==='point'&&!getPoint()){toast('Выберите пункт выдачи или зал');$('#point-box').scrollIntoView({block:'center'});return;}
  const o=calc(),num=Math.floor(Math.random()*900000+100000);
  localStorage.setItem('athlos_orders',JSON.stringify([...JSON.parse(localStorage.getItem('athlos_orders')||'[]'),{num,items:o.c,total:o.total,email:U?U.email:E.email.value.trim().toLowerCase(),where:E.delivery.value==='point'?getPoint().n+', '+getPoint().city+', '+getPoint().a:E.address.value,name:E.fullname.value,phone:E.phone.value,date:new Date().toISOString()}]));
  localStorage.removeItem('athlos_draft');setCart([]);$('#cart-wrap').hidden=true;$('#empty').hidden=true;$('#done').hidden=false;$('#order-num').textContent='№ '+num;$('#done-where').textContent='Получение: '+(E.delivery.value==='point'?getPoint().n+', '+getPoint().city+', '+getPoint().a:E.address.value);$('#order-total').textContent=money(o.total);scrollTo(0,0);};
 draw();
}

/* ---- регистрация, вход, личный кабинет ---- */
$$('[data-keep]').forEach(a=>a.setAttribute('href',a.getAttribute('href')+location.search));
if($('#reg')){const f=$('#reg'),E=f.elements,err=$('#err');
 f.onsubmit=async e=>{e.preventDefault();err.textContent='';const email=E.email.value.trim().toLowerCase();
  if(E.pass.value!==E.pass2.value)return err.textContent='Пароли не совпадают';
  if(users().some(u=>u.email===email)){err.innerHTML='Этот email уже зарегистрирован. <a href="login.html'+location.search+'">Войти</a>';return;}
  jset('athlos_users',[...users(),{name:E.fullname.value.trim(),email,phone:E.phone.value.trim(),pass:await hash(E.pass.value)}]);
  localStorage.setItem('athlos_user',email);location.href=next();};}
if($('#login')){const E=$('#login').elements;
 $('#login').onsubmit=async e=>{e.preventDefault();const u=users().find(x=>x.email===E.email.value.trim().toLowerCase());
  if(!u||u.pass!==await hash(E.pass.value)){$('#err').textContent='Неверный email или пароль';return;}
  localStorage.setItem('athlos_user',u.email);location.href=next();};}
if($('#account')){
 if(!U)location.replace('login.html?next=account.html');
 else{const f=$('#profile'),E=f.elements;E.fullname.value=U.name;E.phone.value=U.phone;E.email.value=U.email;$('#hello').textContent='Здравствуйте, '+U.name.split(' ')[0];
  f.onsubmit=e=>{e.preventDefault();const us=users(),u=us.find(x=>x.email===U.email);u.name=E.fullname.value.trim();u.phone=E.phone.value.trim();jset('athlos_users',us);toast('Данные сохранены');};
  $('#logout').onclick=()=>{localStorage.removeItem('athlos_user');location.href='index.html';};
  const os=jget('athlos_orders','[]').filter(o=>o.email===U.email).reverse();
  $('#orders').innerHTML=os.length?os.map(o=>`<div class="row"><span>Заказ № ${o.num} от ${new Date(o.date).toLocaleDateString('ru-RU')}</span><b>${money(o.total)}</b></div>`).join(''):'<p>Заказов пока нет. <a href="catalog.html">Перейти в каталог</a></p>';}}
if($('#ask'))$('#ask').onsubmit=e=>{e.preventDefault();const E=e.target.elements;jset('athlos_messages',[...jget('athlos_messages','[]'),{name:E.fullname.value,email:E.email.value,msg:E.msg.value,date:new Date().toISOString()}]);e.target.reset();$('#ask-ok').textContent='Спасибо, мы ответим на почту в течение дня.';};

/* ---- страницы категорий и акций ---- */
if($('#cgrid')){
 const k=document.body.dataset.cat,sale=k==='sale',t=sale?'Акции':CATS[k];
 $('#cp-title').textContent=t;$('#cp-crumb').textContent=t;document.title=t+' — Athlos';
 $('#cp-text').textContent=sale?'Товары со скидкой. Выбирайте и экономьте.':CATDESC[k];
 $('#promo-box').hidden=!sale;$('#how').hidden=sale;if(!sale)$('#cp-how').textContent=INFO[k][2];
 $('#copy').onclick=()=>{navigator.clipboard?.writeText('ATHLOS10').catch(()=>{});toast('Промокод ATHLOS10 скопирован');};
 const draw=()=>{const s=$('#sort').value,list=PRODUCTS.filter(p=>sale?p.d>0:p.c===k).sort((a,b)=>s==='asc'?a.s[0][1]-b.s[0][1]:s==='desc'?b.s[0][1]-a.s[0][1]:s==='rate'?b.r-a.r:b.rv-a.rv);
  $('#cp-count').textContent=list.length+' '+pl(list.length);$('#cgrid').innerHTML=list.map(card).join('');};
 $('#sort').onchange=draw;draw();
}
/* ---- пункты выдачи и залы ---- */
if($('#points')){
 const nx=new URLSearchParams(location.search).get('next')||'',back=/^[\w-]+\.html$/.test(nx)?nx:'catalog.html',city=$('#p-city'),q=$('#p-q');
 city.innerHTML='<option value="">Все города</option>'+[...new Set(POINTS.map(p=>p.city))].map(c=>`<option>${c}</option>`).join('');
 const bar=()=>{const p=getPoint();$('#chosen').hidden=!p;if(p){$('#chosen-text').textContent=p.n+', '+p.city+', '+p.a;$('#chosen-go').href=back;$('#chosen-go').textContent=nx?'Вернуться к заказу':'Перейти в каталог';}};
 const draw=()=>{const ty=$('input[name=ptype]:checked').value,s=q.value.trim().toLowerCase(),sel=getPoint(),
  list=POINTS.filter(p=>(!city.value||p.city===city.value)&&(!ty||p.t===ty)&&(!s||(p.n+' '+p.a+' '+p.city).toLowerCase().includes(s)));
  $('#p-count').textContent='Найдено: '+list.length;
  $('#points').innerHTML=list.map(p=>{const on=sel&&sel.id===p.id;return`<article class="point${on?' on':''}"><span class="badge">${p.t==='gym'?'Спортзал':'Пункт выдачи'}</span><h3>${p.n}</h3><p>${p.city}, ${p.a}</p><small>${p.h}</small><button class="btn sm${on?'':' ghost'}" data-pt="${p.id}">${on?'Выбрано':'Выбрать'}</button></article>`;}).join('')||'<p class="empty">Ничего не найдено. Измените город или запрос.</p>';};
 [city,q].forEach(x=>x.addEventListener('input',draw));$$('input[name=ptype]').forEach(x=>x.onchange=draw);
 $('#points').onclick=e=>{const b=e.target.closest('[data-pt]');if(b){localStorage.setItem('athlos_point',b.dataset.pt);localStorage.setItem('athlos_delivery','point');toast('Пункт выбран');draw();bar();}};
 draw();bar();
}
